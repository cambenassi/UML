/**********************************************************************
 *  ps0-readme template                                                   
 *  Hello World Assignment                       
 **********************************************************************/

Your name: Cameron Benassi

Operating system you're using (Linux, OS X, or Windows): Linux via VirtualBox 

IDE or text editor you're using: Visual Studio Code

Hours to complete assignment: 30 mins

/**********************************************************************
 *  Part of Assignment 0 is to read the collaboration policy in syllabus.
 *  
 *  If you haven't done this, please do so now.
 *
 *  Read the University policy Academic Integrity,
 *  and answer the following question:
 *
 * There are six examples of academic misconduct, labeled (a) through
 * (f). Other than (a), "Seeks to claim credit for the work or efforts
 * of another without authorization or citation," which of these do you
 * think would most apply to this class, and why? Write approx. 100-200
 * words.
 *	
 *		
 	I believe that (b) "Uses unauthorized materials or fabricated data
 	in any academic exercise would most apply to this class from the list.
 	Although I do not think the falsified data aspect is relevant for this
 	course, there are certainly unauthorized materials that can be used,
 	such as using a previous student's work for reference, or copying an answer
 	from a coding forum instead of understanding the critisim and implementing
 	the fix yourself.
 
 * Note: there is no single correct answer to this. I am looking for
 * your opinion.
 **********************************************************************/



/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
The SFML Website


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
None


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
